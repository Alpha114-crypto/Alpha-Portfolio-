"use client";

const skills = [
  { name: "HTML5", icon: "fa-brands fa-html5", color: "text-orange-500", desc: "Semantic Markup" },
  { name: "CSS3", icon: "fa-brands fa-css3-alt", color: "text-blue-500", desc: "Styling & Layouts" },
  { name: "JavaScript", icon: "fa-brands fa-js", color: "text-yellow-400", desc: "DOM & Logic" },
  { name: "React", icon: "fa-brands fa-react", color: "text-cyan-400", desc: "Interactive UIs" },
  { name: "PHP", icon: "fa-brands fa-php", color: "text-indigo-400", desc: "Server Scripts" },
  { name: "MySQL / Supabase", icon: "fa-solid fa-database", color: "text-emerald-400", desc: "Data Management" },
];

export default function Skills() {
  return (
    <section className="py-20 bg-slate-900/50 border-y border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
            Stack & Capabilities
          </h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white">Technical Skills</h3>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
          {skills.map((skill) => (
            <div
              key={skill.name}
              className="bg-slate-900 border border-slate-800 p-6 rounded-2xl text-center hover:border-cyan-500/40 transition-all"
            >
              <i className={`${skill.icon} text-4xl ${skill.color} mb-3`}></i>
              <h5 className="font-bold text-white text-sm">{skill.name}</h5>
              <p className="text-xs text-slate-500 mt-1">{skill.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
