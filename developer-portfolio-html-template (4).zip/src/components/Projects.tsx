"use client";

const projects = [
  {
    badge: "Education Portal",
    badgeColor: "bg-cyan-500/10 text-cyan-400",
    icon: "fa-solid fa-school",
    iconColor: "text-cyan-400/80",
    title: "Bright Future Portal",
    desc: "Comprehensive secondary school web portal system designed for student information and portal access.",
    tags: ["HTML", "CSS", "JavaScript"],
    bgGradient: "from-cyan-900/40 to-slate-800",
  },
  {
    badge: "Primary School Site",
    badgeColor: "bg-blue-500/10 text-blue-400",
    icon: "fa-solid fa-graduation-cap",
    iconColor: "text-blue-400/80",
    title: "Primary School Samari Web App",
    desc: "Multi-page website for Primary School Samari integrated with database management capabilities.",
    tags: ["HTML/CSS", "Supabase", "Vercel"],
    bgGradient: "from-blue-900/40 to-slate-800",
  },
  {
    badge: "CBT Examination",
    badgeColor: "bg-emerald-500/10 text-emerald-400",
    icon: "fa-solid fa-laptop-code",
    iconColor: "text-emerald-400/80",
    title: "NAUB Examination & CBT Portal",
    desc: "Timed computer-based test platform designed for university general studies exam management.",
    tags: ["Google Apps Script", "JavaScript"],
    bgGradient: "from-emerald-900/40 to-slate-800",
  },
  {
    badge: "Management System",
    badgeColor: "bg-purple-500/10 text-purple-400",
    icon: "fa-solid fa-user-gear",
    iconColor: "text-purple-400/80",
    title: "iDICE Form & Admin Dashboard",
    desc: "Application platform with secure password-protected admin dashboard for managing beneficiary records.",
    tags: ["HTML/JS", "Google Sheets API"],
    bgGradient: "from-purple-900/40 to-slate-800",
  },
  {
    badge: "LMS Platform",
    badgeColor: "bg-amber-500/10 text-amber-400",
    icon: "fa-solid fa-brain",
    iconColor: "text-amber-400/80",
    title: "Alpha AI Master Class",
    desc: "Learning management web platform with student authentication and structured course modules.",
    tags: ["React", "Supabase Auth"],
    bgGradient: "from-amber-900/40 to-slate-800",
  },
  {
    badge: "Utility App",
    badgeColor: "bg-pink-500/10 text-pink-400",
    icon: "fa-solid fa-calculator",
    iconColor: "text-pink-400/80",
    title: "Scientific Calculator Tool",
    desc: "Interactive React single-page application performing advanced mathematical operations.",
    tags: ["React", "TypeScript"],
    bgGradient: "from-pink-900/40 to-slate-800",
  },
];

export default function Projects() {
  return (
    <section id="projects" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="space-y-4">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
              Portfolio Showcase
            </h2>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-white">
              Developed Applications
            </h3>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <div
              key={project.title}
              className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden hover:border-cyan-500/40 transition-all flex flex-col group"
            >
              <div className={`h-48 border-b border-slate-800 p-6 flex flex-col justify-between ${project.bgGradient}`}>
                <span className={`inline-block px-3 py-1 rounded-full ${project.badgeColor} text-xs font-semibold w-max`}>
                  {project.badge}
                </span>
                <i className={`${project.icon} text-4xl ${project.iconColor} group-hover:scale-110 transition-transform`}></i>
              </div>
              <div className="p-6 flex-grow flex flex-col justify-between space-y-4">
                <div>
                  <h4 className="text-xl font-bold text-white">{project.title}</h4>
                  <p className="text-slate-400 text-sm mt-2">{project.desc}</p>
                </div>
                <div className="flex flex-wrap gap-2 pt-2">
                  {project.tags.map((tag) => (
                    <span key={tag} className="px-2.5 py-1 rounded-md bg-slate-800 text-slate-300 text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
