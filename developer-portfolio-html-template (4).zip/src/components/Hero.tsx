"use client";

export default function Hero() {
  return (
    <section className="relative py-20 lg:py-32 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          {/* Hero Content */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-sm font-medium">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
              Computer Science @ Nigerian Army University Biu
            </div>

            <h1 className="text-4xl sm:text-6xl font-extrabold text-white tracking-tight leading-tight">
              Hi, I&apos;m <span className="gradient-text">Alpha Luka</span>
            </h1>

            <p className="text-lg sm:text-xl text-slate-400 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed">
              A Computer Science student at Nigerian Army University Biu and Software Developer passionate about software development.
            </p>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4">
              <a
                href="#projects"
                className="px-7 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-[1.02] transition-all"
              >
                View My Work <i className="fa-solid fa-arrow-right ml-2"></i>
              </a>
              <a
                href="#contact"
                className="px-7 py-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold border border-slate-700 transition-all"
              >
                Contact Me
              </a>
            </div>

            {/* Quick Badges */}
            <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-slate-400 text-sm">
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-graduation-cap text-cyan-400"></i>
                <span>NAUB Undergraduate</span>
              </div>
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-laptop-code text-cyan-400"></i>
                <span>Full-Stack Developer</span>
              </div>
              <div className="flex items-center gap-2">
                <i className="fa-solid fa-location-dot text-cyan-400"></i>
                <span>Borno State, Nigeria</span>
              </div>
            </div>
          </div>

          {/* Hero Portrait / Frame */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-72 h-72 sm:w-80 sm:h-80 lg:w-96 lg:h-96">
              {/* Background Glow Elements */}
              <div className="absolute -inset-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-3xl blur-2xl opacity-30 animate-pulse"></div>

              <div className="relative w-full h-full rounded-3xl bg-slate-800 border-2 border-slate-700 overflow-hidden shadow-2xl group">
                <img
                  src="profile.jpg"
                  alt="Alpha Luka"
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      "https://ui-avatars.com/api/?name=Alpha+Luka&background=0891b2&color=fff&size=512";
                  }}
                />
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent p-6 text-center">
                  <h3 className="text-lg font-bold text-white">Alpha Luka</h3>
                  <p className="text-xs text-cyan-400 font-medium">
                    Computer Science & Developer
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
