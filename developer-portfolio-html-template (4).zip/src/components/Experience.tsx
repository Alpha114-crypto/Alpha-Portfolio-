"use client";

export default function Experience() {
  const experienceItems = [
    {
      icon: "fa-solid fa-chalkboard-user",
      iconColor: "text-cyan-400",
      iconBg: "bg-cyan-500/10 border border-cyan-500/20",
      category: "Educational Sector",
      title: "Teaching Practice & Mentorship",
      org: "Government Secondary School Shani",
      orgColor: "text-cyan-400",
      bullets: [
        "Delivered structured computer science and ICT fundamental lessons to students.",
        "Mentored students in practical computer usage, logic development, and digital literacy.",
        "Organized academic learning modules, classroom engagements, and practical evaluations.",
      ],
    },
    {
      icon: "fa-solid fa-microchip",
      iconColor: "text-blue-400",
      iconBg: "bg-blue-500/10 border border-blue-500/20",
      category: "Technical Training",
      title: "Industrial Training (SIWES)",
      org: "Nigerian Army University Biu (NAUB) ICT Unit",
      orgColor: "text-blue-400",
      bullets: [
        "Conducted computer hardware troubleshooting, component assembly, and system maintenance.",
        "Managed local database structures, server operations, and backend setups using phpMyAdmin/MySQL.",
        "Supported university portal services, network connectivity, and web software operations.",
      ],
    },
  ];

  return (
    <section id="experience" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
            Practical Knowledge
          </h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white">
            Work & Training Experience
          </h3>
          <p className="text-slate-400">
            Practical hands-on technical experience in IT infrastructure, ICT management, and student teaching practice.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {experienceItems.map((item, index) => (
            <div
              key={index}
              className="bg-slate-900 border border-slate-800 rounded-2xl p-8 hover:border-cyan-500/50 transition-all hover:shadow-xl hover:shadow-cyan-500/5 group"
            >
              <div className={`w-12 h-12 rounded-xl ${item.iconBg} ${item.iconColor} flex items-center justify-center text-xl mb-6 group-hover:scale-110 transition-transform`}>
                <i className={item.icon}></i>
              </div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                {item.category}
              </span>
              <h4 className="text-2xl font-bold text-white mt-2">{item.title}</h4>
              <p className={`${item.orgColor} text-sm font-medium mt-1`}>{item.org}</p>

              <ul className="mt-6 space-y-3 text-slate-400 text-sm">
                {item.bullets.map((bullet, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <i className="fa-solid fa-check text-cyan-400 mt-1"></i>
                    <span>{bullet}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
