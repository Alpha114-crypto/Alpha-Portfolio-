"use client";

import { useState } from "react";

export default function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 5000);
    (e.target as HTMLFormElement).reset();
  };

  const contactInfo = [
    {
      icon: "fa-solid fa-envelope",
      label: "Email Address",
      value: "alphaluka94@gmail.com",
      href: "mailto:alphaluka94@gmail.com",
    },
    {
      icon: "fa-solid fa-phone",
      label: "Phone Number",
      value: "09026775055",
      href: "tel:09026775055",
    },
    {
      icon: "fa-solid fa-location-dot",
      label: "Location",
      value: "Shani East, LGA Borno State, Nigeria",
      href: null,
    },
  ];

  return (
    <section id="contact" className="py-20 bg-slate-900/50 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5 space-y-6">
            <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
              Connect
            </h2>
            <h3 className="text-3xl sm:text-4xl font-extrabold text-white">
              Get In Touch
            </h3>
            <p className="text-slate-400 leading-relaxed">
              Feel free to reach out for software development collaborations, academic inquiries, or technical project consultations.
            </p>

            <div className="space-y-4 pt-4">
              {contactInfo.map((info) => (
                <div key={info.label} className="flex items-center gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="w-10 h-10 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
                    <i className={info.icon}></i>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">{info.label}</p>
                    {info.href ? (
                      <a
                        href={info.href}
                        className="text-white font-medium hover:text-cyan-400"
                      >
                        {info.value}
                      </a>
                    ) : (
                      <p className="text-white font-medium">{info.value}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 p-8 rounded-2xl">
            <form id="contact-form" onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-400">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="John Doe"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-400">Your Email</label>
                  <input
                    type="email"
                    required
                    placeholder="john@example.com"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400">Subject</label>
                <input
                  type="text"
                  required
                  placeholder="Project Inquiry"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-400">Message</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Type your message here..."
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-semibold hover:opacity-90 transition-opacity"
              >
                Send Message
              </button>
            </form>

            {isSubmitted && (
              <div className="mt-4 p-3 rounded-xl bg-green-500/10 border border-green-500/20 text-green-400 text-sm text-center">
                Thank you for reaching out! Alpha Luka will get back to you soon.
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
