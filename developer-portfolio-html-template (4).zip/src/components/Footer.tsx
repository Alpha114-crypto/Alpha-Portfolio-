"use client";

import { useEffect, useState } from "react";

export default function Footer() {
  const [year, setYear] = useState(new Date().getFullYear());

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  return (
    <footer className="bg-slate-950 border-t border-slate-800 py-8 text-center text-xs text-slate-500">
      <div className="max-w-7xl mx-auto px-4">
        <p>© {year} Alpha Luka. All rights reserved.</p>
      </div>
    </footer>
  );
}
