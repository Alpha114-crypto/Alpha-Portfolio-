"use client";

export default function Education() {
  const timelineItems = [
    {
      year: "2006 – 2012",
      title: "Samari Primary School",
      subtitle: "Primary Education",
      cert: "First School Leaving Certificate (2012)",
      side: "left" as const,
    },
    {
      year: "2012 – 2018",
      title: "Government Day Secondary School Marama",
      subtitle: "Secondary Education",
      cert: "Senior Secondary Certificate (2018)",
      side: "right" as const,
    },
    {
      year: "2018 – 2021",
      title: "College of Education Waka Biu",
      subtitle: "Higher Education",
      cert: "Nigeria Certificate in Education (2021)",
      side: "left" as const,
    },
    {
      year: "2025 – Present",
      title: "Nigerian Army University Biu (NAUB)",
      subtitle: "B.Sc. Computer Science (Undergraduate)",
      cert: "Focusing on algorithms, system architecture, database administration, software engineering, and modern web application development.",
      isCurrent: true,
      side: "right" as const,
    },
  ];

  return (
    <section id="education" className="py-20 bg-slate-900/50 border-y border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <h2 className="text-xs font-bold text-cyan-400 uppercase tracking-widest">
            Academic Journey
          </h2>
          <h3 className="text-3xl sm:text-4xl font-extrabold text-white">
            Educational Background
          </h3>
          <p className="text-slate-400">
            A detailed chronological view of schools attended, foundational certifications, and current degree studies.
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Timeline Vertical Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-0.5 bg-slate-800 -translate-x-1/2"></div>

          <div className="space-y-12">
            {timelineItems.map((item, index) => (
              <div key={index} className="relative flex flex-col md:flex-row items-start group">
                {item.side === "left" ? (
                  <>
                    <div className="md:w-1/2 md:pr-12 md:text-right w-full pl-12 md:pl-0 mb-2 md:mb-0">
                      <span className={`inline-block px-3 py-1 rounded-full bg-slate-800 text-cyan-400 text-xs font-semibold mb-2 ${
                        item.isCurrent ? "bg-cyan-500/10 border border-cyan-500/30" : ""
                      }`}>
                        {item.year}
                      </span>
                      <h4 className="text-xl font-bold text-white">{item.title}</h4>
                      <p className="text-slate-400 text-sm mt-1">{item.subtitle}</p>
                      <p className="text-xs text-slate-500 mt-2">{item.cert}</p>
                    </div>
                    <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-slate-900 border-2 border-cyan-500 flex items-center justify-center text-cyan-400 text-xs font-bold z-10">
                      {index + 1}
                    </div>
                    <div className="md:w-1/2 md:pl-12 w-full pl-12 md:pl-0"></div>
                  </>
                ) : (
                  <>
                    <div className="md:w-1/2 md:pr-12 w-full pl-12 md:pl-0 mb-2 md:mb-0"></div>
                    <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-slate-900 border-2 border-cyan-500 flex items-center justify-center text-cyan-400 text-xs font-bold z-10">
                      {index + 1}
                    </div>
                    <div className="md:w-1/2 md:pl-12 w-full pl-12 md:pl-0">
                      <span className={`inline-block px-3 py-1 rounded-full bg-slate-800 text-cyan-400 text-xs font-semibold mb-2 ${
                        item.isCurrent ? "bg-cyan-500/10 border border-cyan-500/30" : ""
                      }`}>
                        {item.year}
                      </span>
                      <h4 className="text-xl font-bold text-white">{item.title}</h4>
                      <p className={item.isCurrent ? "text-cyan-400 text-sm font-semibold mt-1" : "text-slate-400 text-sm mt-1"}>
                        {item.subtitle}
                      </p>
                      <p className="text-xs text-slate-400 mt-2">{item.cert}</p>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
